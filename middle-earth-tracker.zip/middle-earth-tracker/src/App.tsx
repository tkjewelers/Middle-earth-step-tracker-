import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import { Suspense } from 'react';
import { useJourneyStore } from '@/stores/journeyStore';
import { getPositionOnPath } from '@/utils/interpolate';

/**
 * Main App — Phase 2 starting point.
 * 
 * This renders a basic Three.js scene with a flat terrain plane,
 * lighting, and OrbitControls. Each phase will add components here.
 * 
 * Phases to build:
 * 2. ✅ Basic 3D Scene (this file)
 * 3. Terrain.tsx — procedural heightmap
 * 4. Water.tsx, Forests.tsx — geographic features
 * 5. JourneyPath.tsx, LocationMarkers.tsx — journey elements
 * 6. Hobbits.tsx — character game pieces
 * 7. RegionLabels.tsx — billboard text
 * 8. MordorEffects.tsx — volcano, Eye, particles
 * 9. UI overlay components
 * 10. Polish and persistence
 */
export default function App() {
  const milesTraveled = useJourneyStore((s) => s.milesTraveled);
  const position = getPositionOnPath(milesTraveled);

  return (
    <div className="w-full h-full relative">
      {/* 3D Scene */}
      <Canvas
        camera={{
          position: [position.worldPosition.x, 45, position.worldPosition.z + 50],
          fov: 50,
          near: 0.1,
          far: 500,
        }}
        shadows
        gl={{
          antialias: true,
          toneMapping: 3, // ACESFilmic
          toneMappingExposure: 1.1,
        }}
        style={{ background: '#0a0806' }}
      >
        <Suspense fallback={null}>
          {/* Lighting */}
          <ambientLight intensity={0.6} color="#4a4030" />
          <directionalLight
            position={[-40, 60, -30]}
            intensity={1.2}
            color="#ffe8c0"
            castShadow
            shadow-mapSize={[2048, 2048]}
            shadow-camera-near={1}
            shadow-camera-far={200}
            shadow-camera-left={-100}
            shadow-camera-right={100}
            shadow-camera-top={100}
            shadow-camera-bottom={-100}
          />
          <directionalLight position={[60, 30, 50]} intensity={0.3} color="#8090b0" />

          {/* Stars */}
          <Stars radius={180} depth={50} count={1000} factor={3} fade speed={0.5} />

          {/* Placeholder terrain — flat plane */}
          <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
            <planeGeometry args={[200, 160, 1, 1]} />
            <meshStandardMaterial color="#3a4a2a" roughness={0.85} />
          </mesh>

          {/* Water plane */}
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.5, 0]}>
            <planeGeometry args={[200, 160]} />
            <meshStandardMaterial color="#1a3a5a" transparent opacity={0.7} roughness={0.2} />
          </mesh>

          {/* Hobbit placeholder — sphere at current position */}
          <mesh position={[position.worldPosition.x, position.worldPosition.y + 2, position.worldPosition.z]}>
            <sphereGeometry args={[1, 16, 16]} />
            <meshStandardMaterial color="#c9a84c" emissive="#c9a84c" emissiveIntensity={0.5} />
          </mesh>

          {/* Camera controls */}
          <OrbitControls
            target={[position.worldPosition.x, 0, position.worldPosition.z]}
            maxPolarAngle={Math.PI / 2.1}
            minDistance={15}
            maxDistance={150}
            enableDamping
            dampingFactor={0.05}
          />
        </Suspense>
      </Canvas>

      {/* HUD Overlay */}
      <div className="absolute top-4 left-4 bg-me-bg/85 border border-me-border p-4 rounded-sm backdrop-blur-sm max-w-xs">
        <div className="font-heading text-[11px] tracking-[4px] text-me-gold-dim uppercase mb-1">
          The Road Goes Ever On
        </div>
        <div className="text-2xl text-me-gold font-bold mb-1">
          {milesTraveled} <span className="text-sm text-me-gold-dim">miles walked</span>
        </div>
        <div className="text-sm text-me-text mb-2">
          Segment {position.segment.id}: {position.segment.from} → {position.segment.to}
          <span className="text-me-teal ml-1">
            ({Math.round(position.segmentProgress * 100)}%)
          </span>
        </div>
        <div className="w-full h-1 bg-me-parchment rounded">
          <div
            className="h-full rounded"
            style={{
              width: `${(milesTraveled / 1779) * 100}%`,
              background: 'linear-gradient(90deg, #4a6741, #6b8f3c, #5aaa8a)',
            }}
          />
        </div>
        <div className="flex justify-between text-[10px] text-me-muted mt-1">
          <span>Bag End</span>
          <span>{((milesTraveled / 1779) * 100).toFixed(1)}%</span>
          <span>Home</span>
        </div>
      </div>

      {/* Phase indicator */}
      <div className="absolute bottom-4 right-4 text-[10px] text-me-muted">
        Phase 2: Basic 3D Scene ✓ — Ready for Phase 3: Terrain
      </div>
    </div>
  );
}
